# CHAPTER MAP — Edinger / Anatomy of the Psyche

> **Nota:** Páginas são estimadas com base em conhecimento da obra. Confirmar com quality audit do PDF real.
> Processo alquímico = capítulo central. Cada capítulo trata um operatio como gramática psíquica.

---

## Estrutura

| ID | Capítulo | Processo Alquímico | Páginas (estimadas) | Blocos estimados (10p) |
|---|---|---|---|---|
| preface | Preface | — | 1–8 | 1 |
| ch01 | Introduction | Visão geral / contexto histórico | 9–22 | 2 |
| ch02 | Calcinatio | Fogo / Calcinação | 23–52 | 3 |
| ch03 | Solutio | Água / Dissolução | 53–82 | 3 |
| ch04 | Coagulatio | Terra / Coagulação | 83–112 | 3 |
| ch05 | Sublimatio | Ar / Sublimação | 113–142 | 3 |
| ch06 | Mortificatio | Morte / Putrefação | 143–172 | 3 |
| ch07 | Separatio | Separação / Discriminação | 173–202 | 3 |
| ch08 | Coniunctio | União / Conjunção | 203–228 | 3 |
| biblio | Bibliography | — | 229–240 | 1 |

**Total estimado:** ~240 páginas | ~25 blocos

---

## Mapa dos Processos Alquímicos como Gramática Psíquica

| Capítulo | Processo | Elemento | Qualidade Psíquica Central |
|---|---|---|---|
| ch02 | Calcinatio | Fogo | Afetos de calor extremo, raiva, humilhação, desejos ardentes |
| ch03 | Solutio | Água | Dissolução de formas fixas, regresso ao caos, renascimento |
| ch04 | Coagulatio | Terra | Encarnação, fixação do efêmero, confronto com a realidade |
| ch05 | Sublimatio | Ar | Elevação espiritual, abstrações, perigosa abstração |
| ch06 | Mortificatio | Morte | Nigredo, putrefação, aspecto sombrio da transformação |
| ch07 | Separatio | Ar/Fogo | Discriminação dos opostos, análise, separar confusão |
| ch08 | Coniunctio | Todos | Conjunção dos opostos, mysterium coniunctionis de Jung |

---

## Relação com Gramática Neumann (já ativa no SIMB-CORE)

Neumann mapeia estágios de desenvolvimento (uroboros → individuação).
Edinger mapeia processos de transformação (calcinatio → coniunctio).

Os dois sistemas são complementares — não concorrentes:
- Neumann responde: "Em que estágio o operador está?"
- Edinger responde: "Que processo de transformação está ativo?"

Possível uso conjunto: identificar estágio (Neumann) + processo ativo (Edinger) para leitura mais precisa.
