# TEXT EXTRACTION REPORT — Edinger / Anatomy of the Psyche

> **STATUS: PENDING — PDF_NOT_FOUND**
> PDF bruto não encontrado em `cesto/` na data de criação deste pack (2026-06-17).
> Este relatório será atualizado após depósito do PDF e execução do quality audit.

---

## Quality Audit — Campos Pendentes

| Campo | Status |
|---|---|
| Número de páginas | PENDING |
| Camada textual (texto selecionável) | PENDING |
| Qualidade da extração (amostra) | PENDING |
| Páginas com ruído / OCR degradado | PENDING |
| Presença de imagens/figuras alquímicas | PENDING — esperado: sim (gravuras alquímicas históricas) |
| Adequação para leitura integral privada | PENDING |
| SHA256 do arquivo | PENDING |

---

## Checklist de Quality Audit (a executar quando PDF chegar)

```
[ ] PDF abre sem erro
[ ] Texto é selecionável (não é scan puro)
[ ] Extração de amostra (páginas 1, 50, 100, 150) — verificar legibilidade
[ ] Imagens: presença de gravuras alquímicas históricas (esperadas em cada capítulo)
[ ] Cabeçalhos e rodapés extraem como ruído (esperado — limpar no script)
[ ] Notas de rodapé: numeradas ou como texto inline
[ ] Páginas em branco: quantas e onde
[ ] Adequação geral: PASS / PASS_WITH_NOTES / FAIL
```

---

## Expectativas Baseadas no Conhecimento da Obra

- **Edição original (1985):** provavelmente scan com camada OCR de qualidade média
- **Versão z-library:** qualidade variável — depende do arquivo específico
- **Figuras alquímicas:** cada capítulo tem imagens históricas de manuscritos alquímicos
  - Imagens não serão extraídas pelo script (texto apenas)
  - A Iris deve saber que figuras existem mas não estarão nos chunks de texto
- **Qualidade esperada:** adequada para leitura SOURCE-FIRST com possíveis lacunas em páginas com figuras

---

## Ação Necessária

1. Depositar PDF em: `cesto/Anatomy of the psyche  alchemical symbolism in psychotherapy (Edinger, Edward F) (z-library.sk, 1lib.sk, z-lib.sk).pdf`
2. Rodar quality audit manual ou via script
3. Atualizar este relatório com resultados reais
4. Se PASS: proceder com geração de chunks privados
5. Se FAIL: reportar e decidir alternativa com operador
